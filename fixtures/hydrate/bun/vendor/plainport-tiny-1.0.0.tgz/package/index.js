module.exports = (s) => `tiny:${s}`;
